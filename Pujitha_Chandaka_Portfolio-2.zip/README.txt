PUJITHA CHANDAKA PORTFOLIO

How to open:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge/Firefox.
3. The portfolio works as a single-page responsive website.

To customize:
- Replace the "PC" circle with your photo if desired.
- Add your resume PDF and a Resume button.
- Add GitHub, certifications, more projects, or project GitHub/demo links when available.
